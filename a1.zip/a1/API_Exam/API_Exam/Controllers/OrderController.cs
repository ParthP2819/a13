﻿using DataAccess.Data;
using DataAccess.Repository;
using DataAccess.Repository.IRepository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ModelView;
using ModelView.ViewModel;

namespace WebApiExam3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly UserManager<IdentityUser> _userManager;
        public OrderController(IUnitOfWork unitOfWork, UserManager<IdentityUser> userManager)
        {
            _unitOfWork = unitOfWork;
            _userManager = userManager;
        }



        //  list of product Item

        [HttpGet]
        [Route("ProductList")]
        public async Task<IActionResult> PostProductItem()
        {
            var data = _unitOfWork.Product.GetAll();
            var productlist = data.Select(x => new { x.productid, x.name, x.quantity, x.price });

            return Ok(productlist);
        }



        // Select Product From product List
        [Authorize]
        [HttpPost]
        [Route("SelectProduct")]
        public async Task<IActionResult> PostOrder(RequestOrderitem requestOrderitem)
        {

            var userdata = await _userManager.FindByNameAsync(requestOrderitem.username);
            var totalamount = requestOrderitem.Price * requestOrderitem.Quantity;
            if (userdata == null)
            {
                return BadRequest("You have To Login First");
            }
            else
            {
                var check = _unitOfWork.order.GetFirstorDefault(x => x.CustomerName == requestOrderitem.username);
                var orderdata = new OrderDetails();
                if (check == null)
                {


                    orderdata.CustomerName = userdata.UserName;
                    orderdata.CustomerEmail = userdata.Email;
                    orderdata.CustomerContactNo = userdata.PhoneNumber;
                    orderdata.StatusType = StatusType.Open.ToString();
                    orderdata.IsActive = true;
                    orderdata.DisountAmount = 0;
                    orderdata.Note = "";
                    orderdata.TotalAmount = totalamount;


                    _unitOfWork.order.Add(orderdata);
                    _unitOfWork.Save();

                    var orderitemdata = new OrderItemDetails()
                    {
                        Quantity = requestOrderitem.Quantity,
                        OrderId = orderdata.OrderId,
                        ProductId = requestOrderitem.productId,
                    };

                    _unitOfWork.orderitem.Add(orderitemdata);
                    _unitOfWork.Save();
                }
                else
                {
                    var orderid = _unitOfWork.order.GetFirstorDefault(x => x.CustomerName == requestOrderitem.username);
                    var orderitemdata = new OrderItemDetails()
                    {
                        Quantity = requestOrderitem.Quantity,
                        OrderId = orderid.OrderId,
                        ProductId = requestOrderitem.productId,
                    };


                    orderid.TotalAmount = orderid.TotalAmount + totalamount;

                    _unitOfWork.order.Update(orderid);
                    _unitOfWork.Save();



                    _unitOfWork.orderitem.Add(orderitemdata);
                    _unitOfWork.Save();
                }


            }


            return Ok(new ResponseOrderItem() { Message = "Add Item Successfully...." });
        }

        // Get order Details by different filter......
        [Authorize]
        [HttpGet]
        [Route("GetOrder")]
        public async Task<IActionResult> GetOrder(string? statusType, string? Name_or_Email, DateTime? fromdate, DateTime? todate)
        {


            if (statusType == null && Name_or_Email == null && fromdate != null && todate == null)
            {
                var datewise = _unitOfWork.order.GetAll();

                var finaldata = datewise.Where(x => x.OrderDate >= fromdate).ToList();
                if (finaldata.Count == 0)
                {
                    return BadRequest("Data Not Found...");

                }

                return Ok(finaldata);
            }

            if (statusType == null && Name_or_Email == null && fromdate != null && todate != null)
            {
                var datewise = _unitOfWork.order.GetAll();

                var finaldata = datewise.Where(x => x.OrderDate >= fromdate && x.OrderDate <= todate).ToList();
                if (finaldata.Count == 0)
                {
                    return BadRequest("Data Not Found...");

                }

                return Ok(finaldata);
            }


            if (statusType != null && Name_or_Email == null)
            {
                var order = _unitOfWork.order.GetFirstorDefault(x => x.StatusType == statusType);
                return Ok(order);
            }

            if (statusType == null && Name_or_Email != null)
            {
                var order = _unitOfWork.order.GetFirstorDefault(x => x.CustomerName == Name_or_Email);


                if (order == null)
                {
                    var data_a = _unitOfWork.order.GetFirstorDefault(x => x.CustomerEmail == Name_or_Email);
                    return Ok(data_a);
                }

                return Ok(order);

            }





            var data = _unitOfWork.order.GetAll();
            var filterdata = data.Select(x => new { x.OrderId, x.Note, x.StatusType, x.CreatedOn });
            return Ok(filterdata);
        }

        // Get Order Details By id and Show All orderitem And Product....

        [Authorize]
        [HttpGet]
        [Route("GetOrderById")]
        public async Task<IActionResult> GetOrderbyId(int id)
        {

            var idData = (from o in _unitOfWork.order.GetAll()
                          join
                        oi in _unitOfWork.orderitem.GetAll() on
                        o.OrderId equals oi.OrderId
                          where o.OrderId == id
                          select new { oi }).ToList();


            return Ok(idData);
        }


        // update Order Status
        [Authorize]
        [HttpPut]
        [Route("updatestatusById")]
        public async Task<IActionResult> putstatusbyId(int id, StatusType status)
        {

            var idData = _unitOfWork.order.GetFirstorDefault(x => x.OrderId == id);
            if (idData.IsActive != false && idData.StatusType != StatusType.Shipped.ToString())
            {
                idData.StatusType = status.ToString();

                _unitOfWork.order.Update(idData);
                _unitOfWork.Save();
            }



            return Ok(idData);
        }


        // update Order Active or inactive
        [Authorize]
        [HttpPut]
        [Route("updateActive")]
        public async Task<IActionResult> PutActive(int id)
        {

            var idData = _unitOfWork.order.GetFirstorDefault(x => x.OrderId == id);

            idData.IsActive = true;

            _unitOfWork.order.Update(idData);
            _unitOfWork.Save();

            return Ok(idData);
        }

        // Remove orderItem By OrderId

        [Authorize]
        [HttpDelete]
        [Route("DeleteItem")]
        public async Task<IActionResult> DeleteItem(int id)
        {
            var orderitem = _unitOfWork.orderitem.GetAll();
            var deletelist = orderitem.Where(oitem => oitem.OrderId == id).ToList();



            _unitOfWork.orderitem.RemoveRange(deletelist);
            _unitOfWork.Save();

            var orderdata = _unitOfWork.order.GetFirstorDefault(x => x.OrderId == id);
            orderdata.TotalAmount = 0;
            _unitOfWork.order.Update(orderdata);
            _unitOfWork.Save();

            return Ok(new ResponseOrderItem() { Message = "Delete Item Successfully...." });
        }

        //Update OrderItem Quantity
        [Authorize]
        [HttpPut]
        [Route("UpdateOrderitemQuantity")]
        public async Task<IActionResult> UpdateQuantity(int Quantity, int orderItemId)
        {
            var upQuantity = _unitOfWork.orderitem.GetFirstorDefault(x => x.OrderItemId == orderItemId);

            if (Quantity >= 1 && upQuantity.IsActive != false)
            {
                upQuantity.Quantity = Quantity;
                _unitOfWork.orderitem.Update(upQuantity);
                _unitOfWork.Save();
            }
            else
            {
                return Ok(new ResponseOrderItem() { Message = "minimum Quantity Is must be 1" });
            }



            return Ok(new ResponseOrderItem() { Message = "Update Quantity Successfully...." });
        }
    }


}
