﻿using DataAccess.Data;
using DataAccess.Repository.IRepository;
using modelview;

namespace DataAccess.Repository
{
    public class ProductRepo : Repository<Product>, IProductRepo
    {
        private readonly ApplicationDbContext _db;
        public ProductRepo(ApplicationDbContext db) : base(db)
        {
            this._db = db;
        }
    }
}
