﻿using DataAccess.Data;
using DataAccess.Repository.IRepository;
using ModelView;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repository
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly ApplicationDbContext _db;

        public UnitOfWork(ApplicationDbContext db)
        {
            _db= db;
            Product = new ProductRepo(_db);
            order = new Order(_db);
            orderitem = new OrderItem(_db);
        }





        public IProductRepo Product { get; private set; }

        public IOrder order { get; private set; }

        public IOrderItem orderitem { get; private set; }

        public void Save()
        {
            _db.SaveChanges();
        }
    }
}
