﻿namespace API_Finals.DataAccess
{
    public class Class1
    {

    }
}