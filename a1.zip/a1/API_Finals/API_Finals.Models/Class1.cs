﻿namespace API_Finals.Models
{
    public class Class1
    {

    }
}