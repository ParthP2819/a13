﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Azure.Models
{
    public class Product
    {
        [Key]
        public int productid { get; set; }

        public string name { get; set; }
        public string description { get; set; }
        public int price { get; set; }
        public int quantity { get; set; }

        public bool isactive { get; set; }
        public DateTime createdon { get; set; } = DateTime.Now;
        public DateTime modifiedon { get; set; } = DateTime.Now;
    }
}
