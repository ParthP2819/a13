﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Azure.Models.ViewModel
{
    public class GetDraftOrder
    {
        public string Name { get; set; }
        public string PhoneNo { get; set; }
        public IList<productlist>  productList { get; set; }

        public BillAddVM billaddress { get; set; }
        public ShippVm shippAddress { get; set; }
    }
}
