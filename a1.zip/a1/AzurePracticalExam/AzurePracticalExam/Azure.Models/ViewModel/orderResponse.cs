﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Azure.Models.ViewModel
{
    public class orderResponse
    {
        public int OderID { get; set; }
        public string Description { get; set; }
        public string Name { get; set; }
        public string email { get; set; }
        public string status { get; set; }
        public int totalItems { get; set; }
        public double TotalAmount { get; set; }
        public string ShipAddress { get; set; }
}
}
