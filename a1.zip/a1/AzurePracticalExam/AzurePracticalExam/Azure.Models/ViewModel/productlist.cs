﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Azure.Models.ViewModel
{
    public class productlist
    {
        public int productId { get; set; }
        public int quntity { get; set; }
    }
}
