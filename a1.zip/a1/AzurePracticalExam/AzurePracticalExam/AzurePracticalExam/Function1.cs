using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using DataAccessLayer.Data;
using DataAccessLayer.Repository.IRepository;
using DataAccessLayer.Repository;
using Azure.Models;
using Azure.Models.ViewModel;
using System.Linq;

namespace AzurePracticalExam
{
    public class Function1
    {
        private readonly IShippingOrder _dataobj;
        public Function1(IShippingOrder dataobj)
        {
            _dataobj = dataobj; 
        }


        [FunctionName("Check")]
        public  async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = null)] HttpRequest req,
            ILogger log)
        {
          //  var asd= _dataobj.GetOrders();

            return new OkObjectResult("");
        }



        // Add Address for register User


        [FunctionName("AddAddress")]
        public async Task<IActionResult> AddAddressUser(
           [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req,
           ILogger log)
        {


            AddressData adddata = new AddressData();


            

            int check =  int.Parse(req.Query["UserId"]);
           

            var userdata = _dataobj.CheckUser(check);

            if(userdata != null)
            {
                var addre =int.Parse(req.Query["AddressType"]);

                if (addre == 0)
                {
                    adddata.AddressType = BillType.Billing.ToString();
                }
                else
                {
                    adddata.AddressType = BillType.Shipping.ToString();
                }

                adddata.UserId = int.Parse(req.Query["UserId"]);
                adddata.Address = req.Query["Address"];
                adddata.Country = req.Query["Country"];
                adddata.State = req.Query["State"];
                adddata.City = req.Query["City"];
                adddata.PinCode = int.Parse(req.Query["PinCode"]);
                adddata.ContactNo = req.Query["ContactNo"];
                
                adddata.UserId = userdata.UserId;
            }
            else
            {
              

                    Response rep = new Response();
                    rep.Status = false;
                    rep.Message = "InValid UserId";
                    rep.Data = null;

                    return new OkObjectResult(rep);
                
            }
            


            _dataobj.AddAddress(adddata);
            _dataobj.save();

            Response reppass = new Response();
            reppass.Status = true;
            reppass.Message = "Address Add Successfully......";
            reppass.Data = adddata;

            return new OkObjectResult(reppass);
        }



        // Get Address List By UserId

        [FunctionName("GetAddressList")]
        public async Task<IActionResult> GetAddressData(
          [HttpTrigger(AuthorizationLevel.Function, "get", Route = null)] HttpRequest req,
          ILogger log)
        {
            var data = _dataobj.GetAddresses(int.Parse(req.Query["UserId"]));

            if(data.Count() == 0)
            {
                Response rep = new Response();
                rep.Status = false;
                rep.Message = " InValid UserId... ";
                rep.Data= null;
                return new OkObjectResult(rep);
            }
            else
            {
                Response repaddress = new Response();
                repaddress.Status = true;
                repaddress.Message = "GetData Successfully......";
                repaddress.Data = data;

                return new OkObjectResult(repaddress);
            }
        
        }

        // Updatestatus by orderId......

        [FunctionName("UpdateStatus")]
        public async Task<IActionResult> UpdateStatus(
        [HttpTrigger(AuthorizationLevel.Function, "Post", Route = null)] HttpRequest req,
        ILogger log)
        {
            var outdata=_dataobj.UpdateStatus(req.Query["Status"], int.Parse(req.Query["OrderId"]));

          if(outdata==true)
            {
                Response rep=new Response();
                rep.Status = outdata;
                rep.Message= "status update successfully...";
                rep.Data = null;
               _dataobj.save();

           return new ObjectResult(rep);
            }
            else
            {
                Response rep = new Response();
                rep.Status = outdata;
                rep.Message = "something wents wrong...";
                rep.Data = null;

                return new ObjectResult(rep);
            }
        }



        // Create Draft Order....

        [FunctionName("DraftOrder")]
        public async Task<IActionResult> DraftOrder(
      [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req,
      ILogger log)
        {

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            dynamic data = JsonConvert.DeserializeObject<GetDraftOrder>(requestBody);


            var pass=_dataobj.AddDraftOrder(data);

            if (pass == "true")
            {
                return new OkObjectResult(new Response { Status=true,Message=" Add DraftOrder successfully...."});
            }
            else
            {
                return new OkObjectResult(new Response { Status = false, Message = "somthing went wrong......" });
            }

          
        }



        [FunctionName("UpdateOrderAddress")]
        public async Task<IActionResult> UpdateOrderAddress(
             [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req,
             ILogger log)
        {

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            dynamic data = JsonConvert.DeserializeObject<UpdateAddressVM>(requestBody);

            var updateadd= _dataobj.UpdateOrderAddress(data);

            

            if (updateadd != null)
            {
                _dataobj.save();
                return new OkObjectResult(new Response { Status=true,Message="Update Successfully...",Data=updateadd});
            }
            else
            {
               return new OkObjectResult(new Response { Status = false, Message = "something wents wrong...", Data = null });

            }

           
        }


        [FunctionName("GetOrder")]
        public async Task<IActionResult> GetOrder(
             [HttpTrigger(AuthorizationLevel.Function, "Get", Route = null)] HttpRequest req,
             ILogger log)
        {

            return new OkObjectResult("");
        }
    }
}
