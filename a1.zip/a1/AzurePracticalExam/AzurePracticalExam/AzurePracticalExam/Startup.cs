﻿using DataAccessLayer.Data;
using DataAccessLayer.Repository;
using DataAccessLayer.Repository.IRepository;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

[assembly: FunctionsStartup(typeof(AzurePracticalExam.Startup))]
namespace AzurePracticalExam
{
    public class Startup : FunctionsStartup
    {
        public override void Configure(IFunctionsHostBuilder builder)
        {
            string connection = Environment.GetEnvironmentVariable("con");
            builder.Services.AddDbContext<ApplicationDbContext>(options=>options.UseMySql(
                connection, ServerVersion.AutoDetect(connection)));

            builder.Services.AddScoped<IShippingOrder, ShippingOrder>();
        }
    }
}
