﻿using Azure.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Data
{
    public class ApplicationDbContext :DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
            
        }
        public DbSet<Orders> orders { get; set; }
        public DbSet<Users> users { get; set; }
        public DbSet<AddressData> addressdata { get; set; }
        public DbSet<Product> products { get; set; }
        public DbSet<OrderItem> orderitem { get; set; }

        public DbSet<OrderAddress> orderaddress { get; set; }

    }
}
