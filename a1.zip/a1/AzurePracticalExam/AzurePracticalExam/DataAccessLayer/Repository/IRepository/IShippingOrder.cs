﻿using Azure.Models;
using Azure.Models.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Repository.IRepository
{
    public interface IShippingOrder 
    {
        public IEnumerable<Orders> GetOrders();
        
        public void save();
        public Users CheckUser(int checkid);
        public void AddAddress(AddressData addressdata);

        public IEnumerable<AddressData> GetAddresses(int userid);
        public bool UpdateStatus(string status, int orderid);

        public string AddDraftOrder(GetDraftOrder getDraftOrder);

        public AddressData UpdateOrderAddress(UpdateAddressVM updateAddressVM);

        public orderResponse GetOrder(GetFillter getFillter);
    }
}
