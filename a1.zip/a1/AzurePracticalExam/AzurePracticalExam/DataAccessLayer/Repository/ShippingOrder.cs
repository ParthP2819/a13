﻿using Azure.Models;
using Azure.Models.ViewModel;
using DataAccessLayer.Data;
using DataAccessLayer.Repository.IRepository;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace DataAccessLayer.Repository
{
    public class ShippingOrder : IShippingOrder
    {
        private readonly ApplicationDbContext _db;
        public ShippingOrder(ApplicationDbContext db)
        {
            _db = db;
        }

        public void AddAddress(AddressData addressdata)
        {
            _db.addressdata.Add(addressdata);
            
        }

        public string AddDraftOrder(GetDraftOrder getDraftOrder)
        {
            var checkperson = _db.addressdata.Where(x => x.ContactPerson == getDraftOrder.shippAddress.ContactPerson).ToList();
            if (checkperson.Count !=0 )
            {
                return "user Allready Exist..";
            }



            var totalamount = 0;
            var productlist = getDraftOrder.productList;

            foreach(var product in productlist )
            {
                var data= _db.products.Find(product.productId);
                var price = data.price * data.quantity;
                totalamount = totalamount + price;
            }




            Orders order = new Orders()
            {
              StatusType="open",
              CustomerName=getDraftOrder.Name,
              CustomerEmail=getDraftOrder.shippAddress.ContactPerson,
              CustomerContactNo=getDraftOrder.PhoneNo,
              IsActive=true,
              TotalAmount=totalamount,
            };

          _db.orders.Add(order);
          _db.SaveChanges();



           foreach(var product in productlist )
            {
                OrderItem orderItem = new OrderItem()
                {
                    OrderId = order.OrderId,
                    ProductId = product.productId
                };
                _db.orderitem.Add(orderItem);
                _db.SaveChanges();
            }


            AddressData addressDatashipp = new AddressData()
            {
             AddressType= getDraftOrder.shippAddress.AddressType,
             Address=getDraftOrder.shippAddress.Address,
             Country=getDraftOrder.shippAddress.Country,
             State = getDraftOrder.shippAddress.State,
             City = getDraftOrder.shippAddress.City,
             PinCode = getDraftOrder.shippAddress.PinCode,
             ContactNo = getDraftOrder.shippAddress.ContactNo,
             ContactPerson = getDraftOrder.shippAddress.ContactPerson,
             
            };

            AddressData addressDatabill = new AddressData()
            {
                AddressType = getDraftOrder.billaddress.AddressType,
                Address = getDraftOrder.billaddress.Address,
                Country = getDraftOrder.billaddress.Country,
                State = getDraftOrder.billaddress.State,
                City = getDraftOrder.billaddress.City,
                PinCode = getDraftOrder.billaddress.PinCode,
                ContactNo = getDraftOrder.billaddress.ContactNo,
                ContactPerson = getDraftOrder.billaddress.ContactPerson,

            };

            _db.addressdata.Add(addressDatashipp);
            _db.addressdata.Add(addressDatabill);
            _db.SaveChanges();


             var adddata=_db.addressdata.Where(x=>x.ContactPerson==order.CustomerEmail).ToList();

             foreach(var item in adddata)
             {
                OrderAddress orderAddress = new OrderAddress()
                {
                    AddressId= item.AddressId,
                    OrderId=order.OrderId
                };
                _db.orderaddress.Add(orderAddress);
                _db.SaveChanges();
             }


             

            return "true";

        }

        public Users CheckUser(int checkid)
        {
            var data = _db.users.Find(checkid);
            return data;
        }

        public IEnumerable<AddressData> GetAddresses(int userid)
        {
           return _db.addressdata.Where(x=>x.UserId==userid).ToList();
        }

        public dynamic GetOrder(GetFillter getFillter)
        {
            var data = (from order in _db.orders
                        join item in _db.orderitem on order.OrderId equals item.OrderId
                        join orderadd in _db.orderaddress on order.OrderId equals orderadd.OrderId
                        join address in _db.addressdata on orderadd.AddressId equals address.AddressId
                        select new {
                            order.OrderId,
                            order.Note,
                            order.CustomerName,
                            order.CustomerEmail,
                            order.StatusType,
                            address.Address,
                            address.City,
                            address.State,
                            address.PinCode,
                        }).ToList();
           
            return data;
        }

        public IEnumerable<Orders> GetOrders()
        {

            return _db.orders.ToList(); 
        }

               
        public void save()
        {
            _db.SaveChanges();
        }

        public AddressData UpdateOrderAddress(UpdateAddressVM updateAddressVM)
        {
          var data=_db.addressdata.Find(updateAddressVM.AddressId);


            if(data!=null)
            {
                data.Address = updateAddressVM.Address;
                data.City = updateAddressVM.City;
                data.ContactNo = updateAddressVM.ContactNo;
                data.ContactPerson = updateAddressVM.ContactPerson;
                data.Country = updateAddressVM.Country;
                data.PinCode = updateAddressVM.PinCode;
                data.State = updateAddressVM.State;

                _db.addressdata.Update(data);

                return data;
            }
            else
            {
                return data;
            }

          
        }

        public bool UpdateStatus(string status , int orderid)
        {
            var data=_db.orders.Find(orderid);
           
                if(status=="draft" && data.StatusType != "ship" && data.StatusType!="paid")
                {
                data.StatusType=status;
                return true;

                }
                else if(status=="ship" && data.StatusType == "draft" && data.StatusType!="paid")
                {
                    data.StatusType=status;
                    return true;
                }
                else if(status=="paid" && data.StatusType != "draft" && data.StatusType == "ship" && data.StatusType != "open")
                {
                     data.StatusType=status;
                     return true;
                }
                else
                {
                 return false;
                }
           
        }
    }
}
