﻿namespace Azure_api.Models
{
    public class Name
    {
        public IList<string> Names { get; set; }
    }
}
