﻿namespace BlobStorage_File_RtraiveUploadDelete.Models
{
    public class TableStorage
    {
        public string tableName { get; set; }

    }
}
