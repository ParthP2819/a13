﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Xml.Linq;

namespace Exam2Web.Models
{
	public class Employee
	{
		[Key]
		public int Id { get; set; }
		public string Name { get; set; }
		public string Description { get; set; }
		[Range(10000, 100000, ErrorMessage = "Display order must be between 10000 and 90000!!!")]
		public int Salary { get; set; }
		[Display(Name = "Roles")]
		public int RolesId { get; set; }
		[ForeignKey("RolesId")]
		[ValidateNever]
		public Roles Roles { get; set; }
		public bool IsActive { get; set; }
		public DateTime CreatedOn { get; set; } = DateTime.Now;
		public DateTime ModifiedOn { get; set; } = DateTime.Now;
	}
}
