﻿using Exam4API.Models;
using ModelView.ViewModel;

namespace Exam4API.DataAccess.Repository.IRepository
{
    public interface IOrderRepository : IRepository<Order>
    {
        public void Update(Order order);

        public void PostOrder(RequestOrderitem requestOrderitem);
    }
}
