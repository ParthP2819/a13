﻿using Exam4API.DataAccess.Repository.IRepository;
using Exam4API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Xml.Linq;

namespace Exam4API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        private readonly IUnitOfWork _unitOfWork;

      
        public CategoryController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }



        [HttpGet]
        public IEnumerable<Category> Get()
        {
            return _unitOfWork.Category.GetAll();
        }


        [Route("Product")]
        [HttpGet]
        public async Task<IActionResult> GetProduct()
        {

             var data =  _unitOfWork.Product.GetAll();
             var productlist = data.Select(x => new { x.ProductId, x.Name, x.Quantity, x.Price,x.Description });

             return Ok(productlist);

        }


    }
}
