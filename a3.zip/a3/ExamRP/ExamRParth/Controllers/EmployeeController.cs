﻿using ExamRParth.Data;
using ExamRParth.Models;
using ExamRParth.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace ExamRParth.Controllers
{
    public class EmployeeController : Controller
    {
        private ApplicationDbContext _context;
        List<EmployeeDetail> employeeDetails;
        public EmployeeController(ApplicationDbContext dbc)
        {
            _context = dbc;
        }
        public IActionResult Index()
        {
            employeeDetails= _context.employees.ToList();
            return View(employeeDetails);
        }

        //GET
        public IActionResult Upsert(int? id)
        {
            EmpVM empVM = new()
            {
                employees = new(),
                roleLists = _context.roles.Select(a => new SelectListItem {Text = a.RoleName, Value = a.RoleId.ToString() })/*.ToList()*/
            };
            if (id == 0 || id == null)
            {
                return View(empVM);
            }
            else
            {
                var empfromdb = _context.employees.Find(id);
                
                var selectlist = _context.addroles.Where(u => u.EmployeeId == empfromdb.EmployeeId).ToList();
                EmpVM empVmData = new()
                {
                    employees = empfromdb,
                    addrole = selectlist,
                    roleLists = _context.roles.Select(u => new SelectListItem { Text = u.RoleName, Value = u.RoleId.ToString() })
                };
				return View(empVM);
            }

        }


        //Post
        [HttpPost]
        public IActionResult Upsert(EmpVM obj, int? id)
        {
            if (id == 0 || id == null)
            {
                _context.employees.Add(obj.employees);
                _context.SaveChanges();

				string values = obj.employees.Roles;
				string[] afterspilit = values.Split(",");

				for (var i = 0; i < afterspilit.Length - 1; i++)
				{
					var roledata = _context.roles.Where(x => x.RoleName == afterspilit[i]).FirstOrDefault();

					var rdatarole = new EmployeeeRoles
                    {
						RoleId = roledata.RoleId,
						EmployeeId = obj.employees.EmployeeId,


					};
					_context.addroles.Add(rdatarole);
					_context.SaveChanges();
				}
                return RedirectToAction("Index");
            }
            else
            {
                _context.employees.Update(obj.employees);
                _context.SaveChanges();
				string values = obj.employees.Roles;
				string[] afterspilit = values.Split(",");
                var deletedata = _context.addroles.Where(x => x.EmployeeId == obj.employees.EmployeeId).ToList();
				_context.addroles.RemoveRange(deletedata);

				for (var i = 0; i < afterspilit.Length - 1; i++)
				{
					var roledata = _context.roles.Where(x => x.RoleName == afterspilit[i]).FirstOrDefault();



					if (roledata != null)
					{

						var rdatarole = new EmployeeeRoles
						{

							RoleId = roledata.RoleId,
							EmployeeId = obj.employees.EmployeeId,


						};

						_context.addroles.Add(rdatarole);
						_context.SaveChanges();
					}
				}
				return RedirectToAction("Index");
            }
        }

		// Post method For Delete Employee
		public IActionResult Delete(int? id)
		{
			var data = _context.employees.Find(id);
			_context.employees.Remove(data);
			var sdata = _context.addroles.Where(x => x.EmployeeId == id).ToList();
			_context.addroles.RemoveRange(sdata);
			_context.SaveChanges();
			return RedirectToAction("Index");
		}
		public IActionResult IsActive(int? id)
		{
			var data = _context.employees.Find(id);

			if (data.IsActive == true)
			{
				data.IsActive = false;
				_context.SaveChanges();
				return RedirectToAction("Index");
			}
			else
			{
				data.IsActive = true;
				_context.SaveChanges();
				return RedirectToAction("Index");
			}
		}

		//public IActionResult Delete(int id)
		//{
		//    if (ModelState.IsValid)
		//    {
		//        var employeeFromDb = _context.employees.Find(id);
		//        _context.employees.Remove(employeeFromDb);
		//        _context.SaveChanges();
		//        return RedirectToAction("Index");
		//    }
		//    return View();
		//}


		//#region API CALLS
		//[HttpGet]
  //      public IActionResult GetAll()
  //      {
  //          var categorylist = _context.employees.ToList();
  //          var modifiedCategoryList = categorylist.Select(c => new { c.EmployeeId, c.Name, c.Description,c.Salary, IsActive = c.IsActive ? "Active" : "InActive", c.CreatedOn, c.ModifiedOn });
  //          return Json(new { data = modifiedCategoryList }); ;
  //      }
  //      #endregion
    }
}

