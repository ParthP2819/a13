﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace ExamRParth.Models.ViewModels
{
    public class EmpVM
    {
        public EmployeeDetail employees { get; set; }
		public RoleType roleType { get; set; }
        public IEnumerable<SelectListItem> roleLists { get; set; }
		public IEnumerable<EmployeeeRoles> addrole { get; set; }
	}
}
